// Sottoclasse che estende Animale
class Gatto extends Animale {
    @Override
    public void faiIlVerso() {
        System.out.println("Miao!");
    }
}