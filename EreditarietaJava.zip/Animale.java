// Classe base
class Animale {
    public void faiIlVerso() {
        System.out.println("L'animale fa un verso generico.");
    }
}